library(shiny)
library(ggplot2)
library(forecast)
library(readr)
library(DT)

# Define UI ----
ui <- fluidPage(
  
  # Title
  titlePanel("Advanced CPI Forecasting Dashboard"),
  
  # Sidebar Layout
  sidebarLayout(
    sidebarPanel(
      fileInput("file", "Upload CSV File (Date, CPI, Exchange Rate, Inflation, etc.)", 
                accept = c(".csv")),
      
      selectInput("model_type", "Select Model Type:", 
                  choices = c("ARIMA", "ARIMAX")),
      
      numericInput("forecast_months", "Months to Forecast:", 
                   value = 6, min = 1, max = 24),
      
      actionButton("run_forecast", "Run Forecast"),
      
      downloadButton("downloadData", "Download Forecast CSV")
    ),
    
    # Main Panel
    mainPanel(
      tabsetPanel(
        tabPanel("Data Preview", DTOutput("table")),
        tabPanel("CPI Trend", plotOutput("cpi_plot")),
        tabPanel("Forecast Results", plotOutput("forecast_plot")),
        tabPanel("Forecast Table", DTOutput("forecast_table"))
      )
    )
  )
)

# Define Server ----
server <- function(input, output) {
  
  data <- reactive({
    req(input$file)
    df <- read_csv(input$file$datapath)
    
    # Convert Date column
    df$Date <- as.Date(df$Date)
    
    # Ensure numeric conversion
    df <- df %>% mutate(across(where(is.character), as.numeric))
    
    return(df)
  })
  
  output$table <- renderDT({
    req(data())
    datatable(data())
  })
  
  output$cpi_plot <- renderPlot({
    req(data())
    ggplot(data(), aes(x = Date, y = CPI)) +
      geom_line(color = "blue", linewidth = 1.2) +
      labs(title = "CPI Over Time", x = "Date", y = "CPI") +
      theme_minimal()
  })
  
  forecast_results <- eventReactive(input$run_forecast, {
    df <- data()
    
    # Select CPI and external regressors
    cpi_ts <- ts(df$CPI, start = c(as.numeric(format(min(df$Date), "%Y")), as.numeric(format(min(df$Date), "%m"))), frequency = 12)
    
    if (input$model_type == "ARIMA") {
      model <- auto.arima(cpi_ts)
      forecast_values <- forecast(model, h = input$forecast_months)
    } else {
      xreg <- as.matrix(df[, c("Exchange.rate", "Inflation.rates")])
      model <- auto.arima(cpi_ts, xreg = xreg)
      future_xreg <- matrix(rep(colMeans(xreg, na.rm = TRUE), input$forecast_months), nrow = input$forecast_months, byrow = TRUE)
      forecast_values <- forecast(model, xreg = future_xreg, h = input$forecast_months)
    }
    
    return(forecast_values)
  })
  
  output$forecast_plot <- renderPlot({
    req(forecast_results())
    autoplot(forecast_results()) +
      labs(title = paste("CPI Forecast for", input$forecast_months, "Months"), x = "Time", y = "CPI") +
      theme_minimal()
  })
  
  output$forecast_table <- renderDT({
    req(forecast_results())
    forecast_df <- data.frame(Date = seq(max(data()$Date) + 1, by = "month", length.out = input$forecast_months),
                              Point_Forecast = forecast_results()$mean,
                              Lo_80 = forecast_results()$lower[, 1],
                              Hi_80 = forecast_results()$upper[, 1],
                              Lo_95 = forecast_results()$lower[, 2],
                              Hi_95 = forecast_results()$upper[, 2])
    
    datatable(forecast_df)
  })
  
  output$downloadData <- downloadHandler(
    filename = function() { paste("CPI_Forecast_", Sys.Date(), ".csv", sep = "") },
    content = function(file) {
      write.csv(forecast_results(), file, row.names = FALSE)
    }
  )
}


# Run the Shiny app ----
shinyApp(ui, server)